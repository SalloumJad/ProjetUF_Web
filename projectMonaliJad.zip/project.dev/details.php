<?php include("inc/header.inc.php"); ?>

<?php include("inc/data.inc.php"); ?>

<?php
//******************************************* */
// Selection multiple
$result = $pdo->query("SELECT * FROM utilisateur WHERE id_utilisateur");
while ($utilisateur = $result->fetch(PDO::FETCH_OBJ)) { ?>

        <div class="card">
                <div class="card-body">
                        <img src="<?php echo $utilisateur->picture; ?>" class="img-fluid" alt="...">
                        <h5 class="card-title"><?php echo $utilisateur->nom; ?></h5>
                        <h5 class="card-title"><?php echo $utilisateur->prenom; ?></h5>
                        <h5 class="card-title"><?php echo $utilisateur->mail; ?></h5>
                        <a href="modification.php?id=<?php echo $utilisateur->id_utilisateur; ?>" class="btn btn-primary">Modification</a>
                </div>
        </div>  

<?php }
//******************************************* */
?>

<?php include("inc/footer.inc.php"); ?>