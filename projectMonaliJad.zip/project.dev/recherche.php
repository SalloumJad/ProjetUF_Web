<?php include("inc/header.inc.php"); ?>

<?php 

if(!empty($_GET["id_wishlist"])) {
        session_start();

        $isInWishList = false;
        foreach($_SESSION as $key => $value) {
                if ($value == $_GET["id_wishlist"]) {
                        $isInWishList = true;
                }
        }

        if (!$isInWishList) {
                $_SESSION['actu'.$_GET["id_wishlist"]] = $_GET["id_wishlist"];
        }

}

?>



<section class="resume-section p-3 p-lg-5 d-flex justify-content-center" id="profil">
    <div class="w-100">
    <h2 class="mb-5">Annonces</h2>

    <?php
    $result = $pdo->query("SELECT * FROM annonce WHERE disponible = 1 AND titre!=''");
    while ($annonce = $result->fetch(PDO::FETCH_OBJ)) { ?>

            <div class="card">
                    <div class="card-body">
                            <h5 class="card-title"><?php echo $annonce->titre; ?></h5>
                            <p><?php echo substr($annonce->description, 0, 100) . "..."; ?></p>
                            <a href="annonce.php?id=<?php echo $annonce->id_annonce; ?>" class="btn btn-primary">Voir Details</a>
                    </div>
            </div>
    <?php } ?>

    </div>

</section>


<?php include("inc/footer.inc.php"); ?>