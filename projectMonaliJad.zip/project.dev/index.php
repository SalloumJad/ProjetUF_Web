<style>
.welcome {
    display: flex;
    height: 800px;
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center;
    position: relative;
  background-image: url("img/voyage.jpg");
}
</style>

<?php include("inc/header.inc.php"); ?>

<section class="welcome">
</section>

<?php include("inc/footer.inc.php"); ?>