<?php include("inc/header.inc.php"); ?>

<a href="details.php" class="btn btn-primary">details & modification</a>

<?php

if (!empty($_POST)) {
    $name = "";
    if (!empty($_FILES)) {
        foreach ($_FILES["img"]["error"] as $key => $error) {
            if ($error == UPLOAD_ERR_OK) {
                $tmp_name = $_FILES["img"]["tmp_name"][$key];
                $name = basename($_FILES["img"]["name"][$key]);
                move_uploaded_file($tmp_name, "img/$name");
            }
        }
    }

    $_POST["prenom"] = htmlentities($_POST["prenom"], ENT_QUOTES);
    $_POST["nom"] = htmlentities($_POST["nom"], ENT_QUOTES);
    $_POST["mail"] = htmlentities($_POST["mail"], ENT_QUOTES);
    $_POST["bourse"] = htmlentities($_POST["bourse"], ENT_QUOTES);
    $_POST["mdp"] = htmlentities($_POST["mdp"], ENT_QUOTES);

    $command = "INSERT INTO utilisateur (prenom, nom, mail, picture, bourse, mdp) VALUES ('$_POST[prenom]', '$_POST[nom]', '$_POST[mail]', 'img/$name' ,'$_POST[bourse]', '$_POST[mdp]')";
    //$result = $pdo->query($command);
    $requete = $pdo->exec($command);
    echo "le compte a bien ete enregistre !";

}

?>



<div class="from">  
    <form method="POST" action="" enctype='multipart/form-data'>

        <div class="form-group">
            <label for="titre">PRENOM</label>
            <input type="texte" class="form-control" id="prenom" name="prenom">
        </div>

        <div class="form-group">
            <label for="titre">NOM</label>
            <input type="texte" class="form-control" id="nom" name="nom">
        </div>

        <div class="form-group">
            <label for="titre">MAIL</label>
            <input type="email" class="form-control" id="mail" name="mail">
        </div>

        <div class="form-group">
            <label for="titre">Photo</label>
            <input type="file" class="form-control-file" id="img" name="img[]">
        </div>

        <div class="form-group">
            <label for="contenu">BOURSE</label>
            <input type="texte" class="form-control" id="bourse" name="bourse">
        </div>

        <div class="form-group">
            <label for="contenu">PASSWORD</label>
            <input type="password" class="form-control" id="mdp" name="mdp">
        </div>

        <button type="submit" class="btn btn-primary">Enregistrer</button>

    </form>
</div>


<?php include("inc/footer.inc.php"); ?>