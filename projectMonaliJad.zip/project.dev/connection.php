<?php include("inc/header.inc.php"); ?>

<?php $result = $pdo->query("SELECT * FROM utilisateur WHERE nom != NULL"); ?>

<div class="starter-template">  
    <section class="css">
    <form method="POST" action="" enctype='multipart/from-data'>

    <h2>Connexion : </h2>

    <?php
    if(!empty($_POST))
    {
        $result = $pdo->query("SELECT * FROM utilisateur WHERE nom != NULL");
        while ($utilisateur = $result->fetch(PDO::FETCH_OBJ)){
            if ($utilisateur->nom == $_POST[nom] && $utilisateur->prenom == $_POST[prenom] && $utilisateur->mdp == $_POST[mdp]){
	            setcookie("user_connected_cookie", $utilisateur->id_utilisateur, time() + (86400), "/");
	        };
	    }
    }
    ?>

        <div class="form-group">
            <label for="titre">NOM</label>
            <input type="texte" class="form-control" id="nom" name="nom">
        </div>

        <div class="form-group">
            <label for="titre">PRENOM</label>
            <input type="texte" class="form-control" id="prenom" name="prenom">
        </div>

        <div class="form-group">
            <label for="titre">MOT DE PASSE</label>
            <input type="password" class="form-control" id="mdp" name="mdp">
        </div>




        <button type="submit" class="btn btn-primary">Se connecter</button>

    </form>
</section>
</div>


<?php include("inc/footer.inc.php"); ?>