<?php include("inc/header.inc.php"); ?>

<?php

if (!empty($_POST)) {
    $name = "";
    if (!empty($_FILES)) {
        foreach ($_FILES["img"]["error"] as $key => $error) {
            if ($error == UPLOAD_ERR_OK) {
                $tmp_name = $_FILES["img"]["tmp_name"][$key];
                $name = basename($_FILES["img"]["name"][$key]);
                move_uploaded_file($tmp_name, "img/$name");
            }
        }
    }

    $_POST["titre"] = htmlentities($_POST["titre"], ENT_QUOTES);
    $_POST["description"] = htmlentities($_POST["description"], ENT_QUOTES);
    $_POST["places"] = htmlentities($_POST["places"], ENT_QUOTES);
    $_POST["adresse"] = htmlentities($_POST["adresse"], ENT_QUOTES);
    $_POST["prix"] = htmlentities($_POST["prix"], ENT_QUOTES);
    $_POST["date"] = htmlentities($_POST["date"], ENT_QUOTES);

    $result = $pdo->query("INSERT INTO annonce (titre, description, photo1, places, adresse, prix, date) VALUES ('$_POST[titre]', '$_POST[description]', 'img/$name' , '$_POST[places]', '$_POST[adresse]', '$_POST[prix]', '$_POST[date]')");

}

?>



<div class="from">  
    <form method="POST" action="" enctype='multipart/form-data'>

        <div class="form-group">
            <label for="titre">TITRE</label>
            <input type="text" class="form-control" id="titre" name="titre">
        </div>

        <div class="form-group">
            <label for="titre">DESCRIPTION</label>
            <input type="message" class="form-control" id="description" name="description">
        </div>

        <div class="form-group">
            <label for="titre">PHOTO</label>
            <input type="file" class="form-control" id="photo" name="img[]">
        </div>

        <div class="form-group">
            <label for="contenu">PLACES</label>
            <input type="number" class="form-control" id="places" name="places">
        </div>

        <div class="form-group">
            <label for="contenu">ADRESSE</label>
            <input type="text" class="form-control" id="adresse" name="adresse">
        </div>

        <div class="form-group">
            <label for="contenu">PRIX</label>
            <input type="number" class="form-control" id="prix" name="prix">
        </div>

        <div class="form-group">
            <label for="contenu">DATE</label>
            <input type="text" class="form-control" id="date" name="date">
        </div>

        <button type="submit" class="btn btn-primary">Enregistrer</button>

    </form>
</div>








<?php
if ($_COOKIE["user_connected_cookie"] != 0){
    $result = $pdo->query("SELECT * FROM utilisateur");
    $profil = $result->fetch(PDO::FETCH_OBJ); ?>
    <section class="resume-section p-3 p-lg-5 d-flex justify-content-center" id="profil">
        <div class="w-100">
        <h2 class="mb-5">Profil</h2>

        <?php
        while ($profil = $result->fetch(PDO::FETCH_OBJ)) { ?>
            <div class="resume-item d-flex flex-column flex-md-row justify-content-between mb-5">
                <div class="resume-content">
                    <h3 class="mb-0"><?php echo $profil->nom ?></h3>
                    <div class="subheading mb-3"><?php echo $profil->prenom ?></div>
                    <p><?php echo $profil->mail ?></p>
                </div>
                <div class="resume-date text-md-right">
                <span class="text-primary"><?php echo "Bourse : ", $profil->bourse ?></span>


                <button type="submit" class="btn btn-primary">Modifier</button>
            </div>
        
        </div>
        <?php } ?>
        </div>

    </section>
<?php}
else if ($_COOKIE["user_connected_cookie"] == 0) { ?>
   <h3 class="mb-0">Veuillez vous connecter afin d'acc�der � votre profil.</h3>
   <p> Veuillez vous connecter </p>
<?php } ?>



<?php include("inc/footer.inc.php"); ?>