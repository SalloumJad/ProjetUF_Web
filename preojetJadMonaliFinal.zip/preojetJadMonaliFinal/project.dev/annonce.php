<?php include("inc/header.inc.php"); ?>

<?php if (!empty($_GET)) { ?>

    <?php
    $result = $pdo->query("SELECT * FROM annonce WHERE id_annonce = $_GET[id]");
    $annonce = $result->fetch(PDO::FETCH_OBJ);
    ?>   

    <div class="card">
            <img src="<?php echo $annonce->photo1; ?>" class="card-img-top" alt="...">
            <img src="<?php echo $annonce->photo2; ?>" class="card-img-top" alt="...">
            <img src="<?php echo $annonce->photo3; ?>" class="card-img-top" alt="...">
            <div class="card-body">
                    <h5 class="card-title"><?php echo $annonce->titre; ?></h5>
                    <p><?php echo $annonce->description; ?></p>
                    </br>
                    <p><?php echo $annonce->adresse; echo ", du     "; echo $annonce->date; echo ",   "; echo $annonce->places;echo " places avec "; echo $annonce->prix; echo " euros par personne et par journee du sejour" ?></p>
            </div>
    </div> 

<?php } ?>

<?php include("inc/footer.inc.php"); ?>