<?php include("inc/header.inc.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="style/style.css" rel="stylesheet" type="text/css">
    <title>Document</title>
    <style>
.welcome {
    display: flex;
    height: 800px;
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center;
    position: relative;
  background-image: url("img/voyage.jpg");
}
.section h2 {
	font-size:20px;
}
.details{
	
}

.section {
	display: flex;
	display: table-cell;
	position: relative;
	height: 400px;
	margin-left: 55px;
	margin-right: 30px;
	padding: 10px;
	float: left;
	overflow:hidden;
}
.square {
	width: 200px;
	height: 300px;
	border: 1px solid black;
	position: relative;
	background-image: url('img/article1.png');
	background-size: cover;
	background-position: center;
	overflow: hidden;
}
.square .overlay {
	opacity:0.5;
	filter:alpha(opacity=50);
	position: absolute;
	height: 100%;
	width: 100%;
	bottom: -100%;
	transition: 0.5s;
	color: black;
	background-color: #F3F1F1;

}
.square:hover .overlay {
	bottom: 0%;
	transition: 0.5s;
	text-align: center;
}
.overlay button {
	position: relative;
	display: block;
	margin: -20px -50px;
	margin-right: auto;
	margin-left: auto;
	top:50%; 
    left:0%; 
	height: 40px;
	font-weight: 900;
	width: 70%;
	background-color: black;
	color:white;
	font-size: 15px;

}
.square2 {
	width: 200px;
	height: 300px;
	border: 1px solid black;
	position: relative;
	background-image: url('img/article2.jpg');
	background-size: cover;
	background-position: center;
	overflow: hidden;
}
.square2 .overlay {
	opacity:0.5;
	filter:alpha(opacity=50);
	position: absolute;
	height: 100%;
	width: 100%;
	bottom: -100%;
	transition: 0.5s;
	color: black;

}
.square2:hover .overlay {
	bottom: 0%;
	transition: 0.5s;
	text-align: center;
	background-color: #F3F1F1;
}
.square3 {
	width: 200px;
	height: 300px;
	border: 1px solid black;
	position: relative;
	background-image: url('img/artile3.jpeg');
	background-size: cover;
	background-position: center;
	overflow: hidden;
}
.square3 .overlay {
	opacity:0.5;
	filter:alpha(opacity=50);
	position: absolute;
	height: 100%;
	width: 100%;
	bottom: -100%;
	transition: 0.5s;
	color: black;

}
.square3:hover .overlay {
	bottom: 0%;
	transition: 0.5s;
	text-align: center;
	background-color: #F3F1F1;
}

.square4 {
	width: 200px;
	height: 300px;
	border: 1px solid black;
	position: relative;
	background-image: url('img/article4.jpg');
	background-size: cover;
	background-position: center;
	overflow: hidden;
}
.square4 .overlay {
	opacity:0.5;
	filter:alpha(opacity=50);
	position: absolute;
	height: 100%;
	width: 100%;
	bottom: -100%;
	transition: 0.5s;
	color: black;

}
.square4:hover .overlay {
	bottom: 0%;
	transition: 0.5s;
	text-align: center;
	background-color: #F3F1F1;
}



</style>
</head>
<body>


<section class="welcome">
</section>


<section class="hero">
	<section class="section">
		<div class="square square1">
			<div class="overlay">
				<button>voir l'article</button> 
			</div>
		</div>
	<h2>Logements<h2>
	</section>
	<section class="section">
		<div class="square2 square1">
			<div class="overlay">
				<button>voir l'article</button> 
			</div>
		</div>
		<h2>Séjours longue durée</h2>
	</section>
		<section class="section">
		<div class="square3 square1">
			<div class="overlay">
				<button>voir l'article</button> 
			</div>
		</div>
		<h2>Experience en ligne</h2>
	</section>


</body>
</html>

