<?php

$pdo = new PDO("mysql:host=localhost;dbname=db_site_airbnb", "root", "", array
(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
?>