<!DOCTYPE html>
<?php
if(!isset($_COOKIE["user_connected_cookie"])) {
	setcookie("user_connected_cookie", 0, time() + (86400), "/");
}?>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="style/style.css" rel="stylesheet" type="text/css">
    <link href="style/bootstrap.css" rel="stylesheet" type="text/css">
    <script src="https://kit.fontawesome.com/39ddd5380d.js" crossorigin="anonymous"></script>
</head>
<body>
<html lang="en" class="full-height">
<header>
	<a href="" class="logo">
		<img src="img/airban.png">
	</a>
	<nav>
		<ul>
			<li>
				<a href="index.php">ACCUEIL</a>
			</li>
			<li>
				<a href="recherche.php">RECHERCHE D'ANNONCES</a>
			</li>
			<li>
				<a href="profil.php">PROFIL</a>
            </li>
            <li>
				<a href="inscription.php">INSCRIPTION</a>
			</li>
			<li>
				<a href="connection.php">CONNECTION</a>
			</li>
		</ul>
	</nav>	
	<div class="social">
		<ul>
			<li>
				<i class="fab fa-facebook-f"></i>
			</li>
			<li>
				<i class="fab fa-twitter"></i>
			</li>
			<li>
				<i class="fab fa-instagram"></i>
			</li>
		</ul>
	</div>
	</header>
</body>
</html>

<?php include("data.inc.php");?>