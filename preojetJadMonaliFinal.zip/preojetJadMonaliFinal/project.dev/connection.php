<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .starter-template {
    display: block;
    margin: 0 auto;
    width: 400px;
}

.form-group {
    margin-bottom: 1rem;
    text-align: center;
}

.starter-template .form-group label{
    display: block;
    margin: 10px;
    text-align: left;
    color: navy;
    font-weight: bold;
    font-size: 110%;
}
    </style>
</head>
<body>
<?php include("inc/header.inc.php"); ?>


<div class="starter-template">  
    <section class="css">
    <form method="POST" action="profil.php" enctype='multipart/from-data'>

    <h2>Connection : </h2>

    <?php
    if(!empty($_POST))
    {
        $result = $pdo->query("SELECT * FROM utilisateur WHERE nom != NULL");
        while ($utilisateur = $result->fetch(PDO::FETCH_OBJ)){
            if ($utilisateur->nom == $_POST[nom] && $utilisateur->prenom == $_POST[prenom] && $utilisateur->mdp == $_POST[mdp]){
	            setcookie("user_connected_cookie", $utilisateur->id_utilisateur, time() + (86400), "/");
	        };
	    }
    }
    ?>

        <div class="form-group">
            <label for="titre">NOM</label>
            <input type="texte" class="form-control" id="nom" name="nom">
        </div>

        <div class="form-group">
            <label for="titre">PRENOM</label>
            <input type="texte" class="form-control" id="prenom" name="prenom">
        </div>

        <div class="form-group">
            <label for="titre">MOT DE PASSE</label>
            <input type="password" class="form-control" id="mdp" name="mdp">
        </div>




        <button type="submit" class="btn btn-primary">Se connecter</button>

    </form>
</section>
</div>


<?php include("inc/footer.inc.php"); ?>
</body>
</html>